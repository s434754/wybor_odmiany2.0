import React from 'react';
import Form from './Form';

function Home() {
    return (
        
      <div className="druga">
        
        <Form />
        
      </div>
    );
  }
  
  export default Home;