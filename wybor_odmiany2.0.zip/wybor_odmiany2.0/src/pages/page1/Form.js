import React from 'react'
import FormSingup from './FormSingup'
import './Form.css';


const Form = () => {
    return (
        

        <div>
            <FormSingup />
            
        </div>
    )
}

export default Form
