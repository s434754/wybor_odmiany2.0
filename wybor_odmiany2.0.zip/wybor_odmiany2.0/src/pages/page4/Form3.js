import React from 'react'
import FormSingup3_1 from '../page4/FormSingup3_1'
import '../page4/Form3.css';


const Form3 = () => {
    return (
        

        <div >
            
            
            <img className='form-img1' src='img/img2.png' />
            <h1 className='napis1'>Kreator wyboru odmiany</h1>
            <img className='mapka' src='img/mapka.png' />
            <FormSingup3_1 />
                
            
            
            
            
            
        </div>
        
    )
}

export default Form3