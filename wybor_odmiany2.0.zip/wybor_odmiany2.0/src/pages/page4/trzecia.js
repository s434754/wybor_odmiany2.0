import React from 'react';
import Form from '../page1/Form';
import Form3 from '../page4/Form3';
import FormSingup3_1 from '../page4/FormSingup3_1'

function trzecia() {
    return (
      <div className="trzecia">

          
          <img className='form-img1' src='img/img2.png' />
          <FormSingup3_1 />
          
            
            
        
        
        
      </div>
      
    );
  }
  
  export default trzecia;