import React from 'react';

import Form10 from '../page11/Form10.js';

function dziesiata() {
    return (
      <div className="dziewiata">
        <Form10 />
        
        
      </div>
    );
  }
  
  export default dziesiata;