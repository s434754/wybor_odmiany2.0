import React from 'react'
import FormSingup8 from '../page9/FormSingup8'
import FormSingup10 from '../page11/FormSingup10'

import '../page11/Form10.css';


const Form10 = () => {
    return (
        

        <div>
            
            <img className='form7-img' src='img/img2-form4.png' />
            
            <img className='form9-img' src='img/tlo2.png' />

            
            <FormSingup10 />
            
        </div>
        
    )
}

export default Form10