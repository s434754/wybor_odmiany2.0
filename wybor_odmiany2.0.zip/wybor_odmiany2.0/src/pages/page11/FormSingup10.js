import React from 'react'
import { Link } from 'react-router-dom';




const FormSingup10 = () => {
    return (
        <div className="form-content-right2">
            <form className="form10">
                
                
                <div className="tab1"></div>
                <div className="tab2"></div>
                <div className="tab3"></div>
                <div className="tab4"></div>
                <div className="tab5"></div>
                <div className="tab6"></div>
                <div className="tab7"></div>
                <div className="tab8"></div>
                <div className="tab9"></div>
                <div className="tab10"></div>
                <div className="tab11"></div>
                <div className="tab12"></div>
                <div className="tab13"></div>
                <div className="tab14"></div>
                <div className="tab15"></div>
                <div className="tab16"></div>
                <div className="tab17"></div>
                <div className="tab18"></div>
                <div className="tab19"></div>
                <div className="tab20"></div>
                <div className="tab21"></div>
                <div className="tab22"></div>
                <div className="tab23"></div>
                <div className="tab24"></div>
                <div className="tab25"></div>
                <div className="tab26"></div>
                <div className="tab27"></div>
                <label className='lab1'>Gatunek</label>
                <label className='lab2'>Pszenica</label>
                <label className='lab3'>Kukurydza</label>
                <label className='lab4'>Żyto</label>
                <label className='lab5'>Zagrożenie suszą:</label>
                <label className='lab6'>Zagrożenie wymarzaniem:</label>
                <label className='lab8'>Zagrożenie wymoknięciami:</label>
                <label className='lab9'>Udział uprawy w strukturze:</label>
                <label className='lab10'>2010-2020</label>
                <label className='lab11'>2020/2030</label>
                <label className='lab12'>2030/2040</label>
                <label className='lab13'>2010-2020</label>
                <label className='lab14'>2020/2030</label>
                <label className='lab15'>2030/2040</label>
                <label className='lab16'>2010-2020</label>
                <label className='lab17'>2020/2030</label>
                <label className='lab18'>2030/2040</label>
                
                
                
                <Link to='jedenasta'>
                    <button  className='t_dalej8'  >
                        Dalej
                    </button>
                    
                </Link>
                <Link to='dziewiata'>
                    <button  className='t_wroc1'  >
                        Wróć
                    </button> 
                    
                </Link>
               
                

                    
                
                
                
            </form>
            
            
        </div>
        
    )
}

export default FormSingup10