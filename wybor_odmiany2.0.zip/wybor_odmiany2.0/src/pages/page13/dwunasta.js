import React from 'react';

import Form12 from './Form12.js';

function dwunasta() {
    return (
      <div className="dwunasta">
        <Form12 />
        
        
      </div>
    );
  }
  
  export default dwunasta;