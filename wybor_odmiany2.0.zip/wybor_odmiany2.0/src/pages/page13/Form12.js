import React from 'react'
import FormSingup8 from '../page9/FormSingup8'
import FormSingup10 from '../page11/FormSingup10'
import { Link } from 'react-router-dom';

import '../page11/Form10.css';


const Form12 = () => {
    return (
        

        <div>
            
            <img className='form7-img' src='img/img2-form4.png' />
            
            <img className='form9-img' src='img/tlo2.png' />
            <div className="wyb_1"/>
            <div className="wyb1_1"/>
            <div className="wyb2"/>
            <Link to='jedenasta'>
                    <button  className='dropdown_1'  >
                        <img src='img/dropdown.png'/>
                    </button>
                    
            </Link>
            <Link to='trzunasta'>
                    <button  className='dropdown1_1'   >
                        <img src='img/dropdown.png'/>
                    </button>
                    
            </Link>
            <Link to='czternasta'>
                    <button  className='dropdown2_1'   >
                        <img src='img/dropdown.png'/>
                    </button>
                    
            </Link>
            <label className="rok1">Rok 2020</label>
            <label className="rok2_1">Rok 2021</label>
            <label className="rok3_1">Rok 2022</label>
            <div className="line"></div>
            <select className='wybor1'>
                        <option value="pszenica">Pszenica</option>
                        <option value="kukurydza">Kukurydza</option>
                        <option value="zyto">Żyto</option>
            </select>
            <p className='plon'>Oczekiwany plon:</p>
            <p className='nawoz'>Czy nawożenie obornikiem:</p>
            <p className='dawka'>Dawka:</p>
            <p className='sloma'>Gospodarowanie słomą:</p>
            <p className='praktyki'>Praktyki klimatyczno-środowiskowe:</p>
            <div className='pol' ></div>
            <div className='pol1' ></div>
            <div className='pol2' ></div>
            <div className='pol3' ></div>
            <div className='pol4' ></div>
            <p className='potrzeby'>Potrzeby pokarmowe upraw</p>
            <div className='pol_1' ></div>
            <div className='pol1_1' ></div>
            <div className='pol2_1' ></div>
            <div className='pol3_1' ></div>
            <div className='pol4_1' ></div>
            <p className='n'>N</p>
            <p className='P2O5'>P2O5</p>
            <p className='K20'>K20</p>
            <p className='Mg'>Mg</p>
            <p className='CaO'>CaO</p>
            <Link to='jedenasta'>
                    <button  className='t_dalej8_1'  >
                        Zapisz
                    </button>
                    
            </Link>
            
                    
            

            
            
            
        </div>
        
    )
}

export default Form12