import React from 'react';

import Form7 from '../page8/Form7';

function siodma() {
    return (
      <div className="siodma">
        <Form7 />
        
        
      </div>
    );
  }
  
  export default siodma;