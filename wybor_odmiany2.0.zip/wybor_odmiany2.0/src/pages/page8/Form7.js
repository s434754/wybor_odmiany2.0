import React from 'react'
import FormSingup7 from '../page8/FormSingup7'
import '../page8/Form7.css';


const Form7 = () => {
    return (
        

        <div>
            
            <img className='form7-img' src='img/img2-form4.png' />
            <img className='mapa-strefy' src='img/mapa-strefy.png' />

            
            <FormSingup7 />
            
        </div>
        
    )
}

export default Form7 