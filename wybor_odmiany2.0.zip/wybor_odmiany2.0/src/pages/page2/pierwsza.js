import React from 'react';
import Form from '../page1/Form';
import Form1 from '../page2/Form1';

function pierwsza() {
    return (
      <div className="pierwsza">
        <Form1 />
        
        
      </div>
    );
  }
  
  export default pierwsza;