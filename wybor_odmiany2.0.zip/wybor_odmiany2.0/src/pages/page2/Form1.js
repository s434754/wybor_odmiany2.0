import React from 'react'
import FormSingup1 from '../page2/FormSingup1'
import '../page2/Form1.css';


const Form1 = () => {
    return (
        

        <div >
            
            <img className='form-img11' src='img/img2.png' />
            <h1 className='napis1_1'>Zdefiniuj pole pod uprawę</h1>
            <h1 className='napis1_2'>Informacje o działce</h1>
            <img className='mapka' src='img/mapka.png' />
                
            
            
            <FormSingup1 />
            
            
        </div>
        
    )
}
export default Form1