import React from 'react';
import Form from '../page1/Form';
import Form6 from '../page7/Form6';

function szusta() {
    return (
      <div className="szusta">
        <Form6 />
        
        
      </div>
    );
  }
  
  export default szusta;