import React from 'react'
import FormSingup6 from '../page7/FormSingup6'
import '../page7/Form6.css';


const Form6 = () => {
    return (
        

        <div>
            
            <img className='form4-img' src='img/img2-form4.png' />
            <h1 className='napis'>Kreator wyboru odmiany</h1>
            <h2 className='napis2'>Sezon 2019</h2>
            <img className='mapka' src='img/mapka.png' />
            <FormSingup6 />
            
        </div>
        
    )
}

export default Form6