import React from 'react'
import FormSingup4 from '../page5/FormSingup4'
import '../page5/Form4.css';


const Form4 = () => {
    return (
        

        <div>
            
            <img className='form4-img' src='img/img2-form4.png' />
            <h1 className='napis'>Kreator wyboru odmiany</h1>
            <h2 className='napis2'>Sezon 2017</h2>
            <img className='mapka' src='img/mapka.png' />
            <FormSingup4 />
            
        </div>
        
    )
}

export default Form4