import React from 'react';
import Form from '../page1/Form';
import Form4 from '../page5/Form4';

function czwarta() {
    return (
      <div className="czwarta">
        <Form4 />
        
        
      </div>
    );
  }
  
  export default czwarta;