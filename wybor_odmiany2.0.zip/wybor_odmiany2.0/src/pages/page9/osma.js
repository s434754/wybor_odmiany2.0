import React from 'react';

import Form8 from '../page9/Form8';

function osma() {
    return (
      <div className="osma">
        <Form8 />
        
        
      </div>
    );
  }
  
  export default osma;