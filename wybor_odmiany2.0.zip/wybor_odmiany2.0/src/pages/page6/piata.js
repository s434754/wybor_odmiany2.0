import React from 'react';
import Form from '../page1/Form';
import Form5 from '../page6/Form5';

function piata() {
    return (
      <div className="piata">
        <Form5 />
        
        
      </div>
    );
  }
  
  export default piata;