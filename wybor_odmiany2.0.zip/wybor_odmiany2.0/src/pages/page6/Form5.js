import React from 'react'
import FormSingup5 from '../page6/FormSingup5'
import '../page6/Form5.css';


const Form5 = () => {
    return (
        

        <div>
            
            <img className='form4-img' src='img/img2-form4.png' />
            <h1 className='napis'>Kreator wyboru odmiany</h1>
            <h2 className='napis2'>Sezon 2018</h2>
            <img className='mapka' src='img/mapka.png' />
            <FormSingup5 />
            
        </div>
        
    )
}

export default Form5