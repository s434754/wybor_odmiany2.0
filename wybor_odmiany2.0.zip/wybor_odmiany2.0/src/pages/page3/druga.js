import React from 'react';

import Form3 from '../page3/Form2';

function druga() {
    return (
      <div className="druga">
        <Form3 />
        
        
        
      </div>
      
    );
  }
  
  export default druga;