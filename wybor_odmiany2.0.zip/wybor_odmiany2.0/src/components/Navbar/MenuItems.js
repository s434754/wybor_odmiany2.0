
export const MenuItems = [
    {
        title: 'Karty pól',
        url: '#',
        cName: 'nav-links'
       
    },
    {
        title: 'Profile upraw',
        url: '#',
        cName: 'nav-links'
    }
      
]